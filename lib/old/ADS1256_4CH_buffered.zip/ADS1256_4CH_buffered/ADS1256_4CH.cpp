#include "Arduino.h"
#include <SPI.h>
#include "ADS1256_4CH.h"

//#define DEBUG_ADS1256
// Constructors
// Construct with only chip select pin, user handles drdy.
ADS1256::ADS1256(int cs){
  _cs = cs;
  _data_ch0 = data0_ch0;
  _data_ch1 = data0_ch1;
  _data_ch2 = data0_ch2;
  _data_ch3 = data0_ch3;

  _storedData_ch0=NULL;
  _storedData_ch1=NULL;
  _storedData_ch2=NULL;
  _storedData_ch3=NULL;

  #ifdef DEBUG_ADS1256
  if (!Serial) {
    Serial.begin(115200);
    while (!Serial);
  }
  #endif
  SPI.begin();         
  pinMode(_cs, OUTPUT);
  digitalWrite(_cs, HIGH);

  //Reset the chip to defaults
  delay(10);
  reset();
  delay(10);
 
  uint8_t id = ADS1256_ReadChipID();  
  if (id != 3)
  {
    Serial.print("Error, ADS1256 Chip ID = ");
    Serial.println(id);
    return;
  }
  else
  {
    #ifdef DEBUG_ADS1256
    Serial.println("Ok, ADS1256 Chip ID = 0x03");
    #endif
  }
}

// Constructor, must input CS pin and DRDY pin.
// configure ADC with gain=1/1 and sampling speed 2000SPS
ADS1256::ADS1256(int cs, int drdy, ADS1256_DRATE_E rate) : ADS1256(cs) {  
  _drdy = drdy; 
  pinMode(_drdy, INPUT);
     
  // Call configuration function
  if(configADC(ADS1256_GAIN_1, rate))
  {
    #ifdef DEBUG_ADS1256
    Serial.println("ADC configuration success");
    #endif
  }
  else
  {
    Serial.println("ADC configuration failed");
  }
}

// Construct with default sampling rate of 2kSPS
ADS1256::ADS1256(int cs, int drdy) : ADS1256(cs,drdy,ADS1256_2000SPS){
}

// update the number of channels to use
void ADS1256::setNumChannels(int n) {
	numChannels = n;
}

// Send multiple SPI bytes at once with correct waiting periods
void ADS1256::transferBytes(int numBytes)
{
  SPI.beginTransaction(SPISETTINGS);
  digitalWrite(_cs, LOW);
  delayMicroseconds(2);
  for(int i = 0; i < numBytes; i++)
  {
    SPIbuffer[i] = SPI.transfer(SPIbuffer[i]);
    delayMicroseconds(2);
  }
  delayMicroseconds(2);
  digitalWrite(_cs, HIGH);
  SPI.endTransaction();
}

//With multiple channels we can not run in continuous mode but this function is kept for 
// compatibility with single channel ino scripts
void ADS1256::startCollecting()
{  
  /*SPI.beginTransaction(SPISETTINGS);
  digitalWrite(_cs,LOW);
  SPI.transfer(RDATAC);
  digitalWrite(_cs,HIGH);
  SPI.endTransaction();
*/
  #ifdef DEBUG_ADS1256
  Serial.println("Starting ADC");
  #endif
}

//With multiple channels we can not run in continuous mode but this function is kept for 
// compatibility with single channel ino scripts
void ADS1256::stopCollecting()
{
  #ifdef DEBUG_ADS1256
  Serial.println("Stopping ADC");  
  #endif
}

// ISR that takes data from ADS1256 during continous read mode, converts the register values to the right value, and writes it to the current data buffer
// when the data buffer is full t7he function returns true to inform the user of ADS1256 about reading the data.
bool ADS1256::collectData(void){  
  // Multiple channels collection is explained in page 21 of datasheet.  
  uint8_t currentChannel=nextChannel;
  nextChannel=nextChannel+1;
  nextChannel= nextChannel > (numChannels - 1) ? 0 : nextChannel;
  
  // On data ready change the mux using WREG
  SPIbuffer[0] = WREG << 4 | MUX;
  SPIbuffer[1] = 0x00; // Number of bytes-1
  SPIbuffer[2] = (nextChannel << 4) | 0x08; // MUX: Psel=AIN0 NSEL=AINCOM
  transferBytes(3);
  // Then send a sync
  SPIbuffer[0] = SYNC;
  transferBytes(1);
  // Then send a wakeup
  SPIbuffer[0] = WAKEUP;
  transferBytes(1);
  
  SPI.beginTransaction(SPISETTINGS);
  digitalWrite(_cs,LOW);
  SPI.transfer(RDATA);
  delayMicroseconds(20);
  SPIbuffer[0] = 0;
  SPIbuffer[1] = 0;
  SPIbuffer[2] = 0;
  SPI.transfer(SPIbuffer, 3);
  digitalWrite(_cs, HIGH);
  SPI.endTransaction();
  Serial.print(SPIbuffer[0],HEX);
  Serial.print("-");
  Serial.print(SPIbuffer[1],HEX);
  Serial.print("-");
  Serial.println(SPIbuffer[2],HEX);
  
  uint32_t data = SPIbuffer[0] << 16 | SPIbuffer[1] << 8 | SPIbuffer[2];
  //Extending Two's compliment 24bit
  data=data^0x800000;  
  float * _data;
  switch (currentChannel){
	case 0:
		_data=_data_ch0;		
		break;
	case 1:
		_data=_data_ch1;
		break;
	case 2:
		_data=_data_ch2;
		break;
	case 3:
		_data=_data_ch3;		
		break;
	default:
		_data=_data_ch0;
		break;
   }

  _data[sampleCount] = 2*VREF*(((float)data/8388607.0)-1);//Voltage
  
  if (currentChannel == (numChannels - 1)){
    sampleCount=sampleCount+1;
    //Serial.println(sampleCount);
  }
  if (sampleCount>=ADS1256_BUFFERSIZE){	
    this->bufferIdx= !(this->bufferIdx);
    _data_ch0= bufferIdx == false ? data0_ch0 : data1_ch0 ;
    _storedData_ch0= bufferIdx == true ? data0_ch0 : data1_ch0 ;
    _data_ch1= bufferIdx == false ? data0_ch1 : data1_ch1 ;
    _storedData_ch1= bufferIdx == true ? data0_ch1 : data1_ch1 ;
    _data_ch2= bufferIdx == false ? data0_ch2 : data1_ch2 ;
    _storedData_ch2= bufferIdx == true ? data0_ch2 : data1_ch2 ;
    _data_ch3= bufferIdx == false ? data0_ch3 : data1_ch3 ;
    _storedData_ch3= bufferIdx == true ? data0_ch3 : data1_ch3 ;
    sampleCount=0;    
    return true;      
  }
  else{
    return false;
  }   
}


float* ADS1256::get_data(int channel) {
  switch (channel){
	case 0:
	  return _storedData_ch0;
	case 1:
	  return _storedData_ch1;
	case 2:
	  return _storedData_ch2;
	case 3:
	  return _storedData_ch3;
	default:
	  return _storedData_ch0;
  }
}

int ADS1256::get_sampleCount() {
  return sampleCount;
}

int ADS1256::bufferSize() {
  return ADS1256_BUFFERSIZE;
}

void ADS1256::reset()
{
  SPI.beginTransaction(SPISETTINGS);
  digitalWrite(_cs,LOW);
  SPI.transfer(RESET);    
  digitalWrite(_cs,HIGH);
  SPI.endTransaction();
  reset_data();
  _data_ch0 = data0_ch0;
  _data_ch1 = data0_ch1;
  _data_ch2 = data0_ch2;
  _data_ch3 = data0_ch3;

  _storedData_ch0=NULL;
  _storedData_ch1=NULL;
  _storedData_ch2=NULL;
  _storedData_ch3=NULL;
}

//I don't think tthis function is really necessary but I'm keeping it just in case
void ADS1256::reset_data() 
{
  memset(data0_ch0,0,sizeof(ADS1256_BUFFERSIZE*sizeof(float)));
  memset(data1_ch0,0,sizeof(ADS1256_BUFFERSIZE*sizeof(float)));
  memset(data0_ch1,0,sizeof(ADS1256_BUFFERSIZE*sizeof(float)));
  memset(data1_ch1,0,sizeof(ADS1256_BUFFERSIZE*sizeof(float)));
  memset(data0_ch2,0,sizeof(ADS1256_BUFFERSIZE*sizeof(float)));
  memset(data1_ch2,0,sizeof(ADS1256_BUFFERSIZE*sizeof(float)));
  memset(data0_ch3,0,sizeof(ADS1256_BUFFERSIZE*sizeof(float)));
  memset(data1_ch3,0,sizeof(ADS1256_BUFFERSIZE*sizeof(float)));

}


// Get the first for registers which contains all the configuration registers
void ADS1256::get_setRegs() {
  uint8_t read[4];
  read[0] = ADS1256_ReadReg(0x00);
  Serial.println(read[0]);
  read[1] = ADS1256_ReadReg(0x01);
  Serial.println(read[1]);
  read[2] = ADS1256_ReadReg(0x02);
  Serial.println(read[2]);
  read[3] = ADS1256_ReadReg(0x03);
  Serial.println(read[3]);  
}

ADS1256::~ADS1256()
{
  SPI.endTransaction();
  SPI.end();
}


