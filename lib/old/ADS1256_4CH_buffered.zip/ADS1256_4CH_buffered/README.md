#ADS1256_4CH Library#

![ADS1256_4CH library Arduino compatible oriented to a 4-channel single input board]

Teddy Johnson, Jonathan Camargo, Will Flanagan
